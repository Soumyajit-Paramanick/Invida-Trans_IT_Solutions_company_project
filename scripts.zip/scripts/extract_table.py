import os
import re
import textwrap
from docx import Document

MAX_WIDTH = 72  # max full line width

# ---------- Utility: Split number for alignment ----------
def split_number(val):
    match = re.match(r"^([\$\+\-\@\#%]*)(\d+)(?:\.(\d+))?(.*)$", val.strip())
    if match:
        prefix, int_part, decimal, suffix = match.groups()
        decimal = decimal if decimal else ""  # Only keep decimal if it exists
        return (prefix + int_part, decimal + suffix)
    return (val.strip(), "")

# ---------- Detect and Align Columns ----------
def align_columns(table_rows):
    col_count = max(len(row) for row in table_rows)
    columns = [[] for _ in range(col_count)]

    # Normalize number of cells per row
    for row in table_rows:
        for i in range(col_count):
            columns[i].append(row[i] if i < len(row) else "")

    aligned = []
    for col in columns:
        split_col = [split_number(cell) for cell in col]
        is_numeric_col = sum(1 for left, _ in split_col if re.search(r'\d', left)) >= len(col) * 0.5

        if is_numeric_col:
            max_left = max(len(left) for left, _ in split_col)
            max_right = max(len(right) for _, right in split_col)

            aligned_col = []
            for left, right in split_col:
                pad = " " * (max_left - len(left))
                aligned_col.append([pad + left + "." + right.ljust(max_right) if right else left])
            aligned.append(aligned_col)
        else:
            aligned_col = []
            for left, right in split_col:
                content = (left + right).strip()
                aligned_col.append([content])  # no leading padding
            aligned.append(aligned_col)

    return list(map(list, zip(*aligned)))  # transpose back to rows

# ---------- Wrap table with blocks and strict alignment ----------
def wrap_table(table_data):
    if not table_data:
        return ["[WARNING: No table found]"]

    num_cols = len(table_data[0])
    col_widths = [0] * num_cols

    for row in table_data:
        for i, cell_lines in enumerate(row):
            for line in cell_lines:
                col_widths[i] = max(col_widths[i], len(line))

    # Split wide tables into blocks
    blocks = []
    current_block = [0]
    current_width = col_widths[0]

    for i in range(1, num_cols):
        projected = current_width + 2 + col_widths[i]
        if projected <= MAX_WIDTH:
            current_block.append(i)
            current_width = projected
        else:
            blocks.append(current_block)
            current_block = [0, i]
            current_width = col_widths[0] + 2 + col_widths[i]
    blocks.append(current_block)

    # Build wrapped table block by block
    output_lines = []
    for block in blocks:
        for row in table_data:
            # Wrap each cell
            wrapped_cells = []
            for i in block:
                cell_lines = []
                for content in row[i]:
                    lines = textwrap.wrap(content, width=col_widths[i]) or ['']
                    cell_lines.extend(lines)
                wrapped_cells.append(cell_lines)

            max_lines = max(len(cell) for cell in wrapped_cells)

            for l in range(max_lines):
                line = ''
                for j, col_idx in enumerate(block):
                    content = wrapped_cells[j][l] if l < len(wrapped_cells[j]) else ''
                    line += content.ljust(col_widths[col_idx])
                    if j < len(block) - 1:
                        line += '  '  # 2-space column gap
                output_lines.append(line.rstrip())
        output_lines.append("")
    return output_lines

# ---------- Main DOCX Processor ----------
def extract_text_and_tables(docx_path, output_txt_path):
    doc = Document(docx_path)
    output_lines = []
    table_idx = 0
    inside_block = False
    block_buffer = []

    for para in doc.paragraphs:
        text = para.text.strip()

        if text == "#@":
            inside_block = True
            block_buffer = []
            continue
        elif text == "@#":
            inside_block = False
            if block_buffer:
                output_lines.append("<TB>")
                output_lines.extend(block_buffer)
                output_lines.append("</TB>\n")
            continue

        if inside_block:
            if re.match(r"^TABLE\s+\d+", text, re.IGNORECASE):
                block_buffer.append(textwrap.fill(text, width=MAX_WIDTH))
                try:
                    table = doc.tables[table_idx]
                    table_idx += 1
                    table_data = []
                    for row in table.rows:
                        cells = [cell.text.replace('\n', ' ').replace('\r', '').strip() for cell in row.cells]
                        if any(cell.strip() for cell in cells):
                            table_data.append(cells)
                    if table_data:
                        aligned = align_columns(table_data)
                        wrapped = wrap_table(aligned)
                        block_buffer.extend(wrapped)
                    else:
                        block_buffer.append("[WARNING: Empty table]")
                except IndexError:
                    block_buffer.append("[WARNING: No table found]")
            else:
                block_buffer.extend(textwrap.wrap(text, width=MAX_WIDTH))

    os.makedirs(os.path.dirname(output_txt_path), exist_ok=True)
    with open(output_txt_path, "w", encoding="utf-8") as f:
        for line in output_lines:
            f.write(line + "\n")
    print(f"[✓] Saved: {output_txt_path}")

# ---------- Batch Processing ----------
if __name__ == "__main__":
    input_folder = "../input_docs"
    output_folder = "../output_text"
    os.makedirs(output_folder, exist_ok=True)

    for filename in os.listdir(input_folder):
        if filename.lower().endswith(".docx"):
            input_path = os.path.join(input_folder, filename)
            base_name = os.path.splitext(filename)[0]
            output_path = os.path.join(output_folder, base_name + ".txt")
            extract_text_and_tables(input_path, output_path)
