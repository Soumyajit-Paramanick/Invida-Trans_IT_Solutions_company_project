# app.py
import os
import tkinter as tk
from tkinter import filedialog, messagebox
from extract_table import extract_text_and_tables

def select_folder():
    folder_selected = filedialog.askdirectory()
    folder_path.set(folder_selected)

def generate_txt():
    input_folder = folder_path.get()
    if not input_folder:
        messagebox.showwarning("Warning", "Please select a folder first.")
        return

    output_folder = os.path.join(input_folder, "output_text")
    os.makedirs(output_folder, exist_ok=True)  # Create output folder if it doesn't exist

    for filename in os.listdir(input_folder):
        if filename.lower().endswith(".docx"):
            input_path = os.path.join(input_folder, filename)
            base_name = os.path.splitext(filename)[0]
            output_path = os.path.join(output_folder, base_name + ".txt")
            extract_text_and_tables(input_path, output_path)

    messagebox.showinfo("Success", "You can check the output now!")

# Create the main window
root = tk.Tk()
root.title("IEFF Table Tool")
root.geometry("400x200")

# Create a string variable to store the folder path
folder_path = tk.StringVar()

# Create UI elements
select_button = tk.Button(root, text="Select Folder", command=select_folder)
select_button.pack(pady=10)

folder_label = tk.Label(root, textvariable=folder_path)
folder_label.pack(pady=5)

generate_button = tk.Button(root, text="Generate TXT", command=generate_txt)
generate_button.pack(pady=10)

# Run the application
root.mainloop()
